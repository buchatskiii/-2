a = 'Топинамбур'
print(a[0])
print(a[-1])
print(a[-5:])
print(a[::-1])
print(a[1::2])